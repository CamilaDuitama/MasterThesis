
###############################################################################
############ This file takes in training data for Glioblastoma #################
################################################################################
rm(list =ls())
################################################
######## Load the Data #########################

######## Input ###############
#### Overall Survival Time Vector (N*1)
time
########### Event or Not Vector (N * 1) ####
censoring
######### mRNA (or miRNA expression values) (N*D) ###
Y.pre.train

######### Signature of SBC ###############
signature.sbc


######## Verhaak Signature ###############
signature.vk

######## Verhaak Labels #################
labels.vk


########################################################################
###### We prepare the Data Structures Needed for the Running of the SBC ####
#############################################################################

Y <- Y.pre.train[as.character(signature.sbc),]
c.true <- labels.vk
levels(c.true) <- c(1,2,3,4)

###### Scaling the data #########
Y <- scale(Y, center = TRUE, scale = TRUE)

######
N <- nrow(Y)
D <- ncol(Y)
smod <-  Surv(exp(time), censoring)

##### Initial number of clusters
k =4
F =k


##################### STATE OF THE ART TECHNIQUES #################################
##################### BASIC METHODS + SOME ADVANCED METHODS ########################

source('Comparisonx.R')
Comparisonx()

source('ComparisionFLX.R')
ComparisionFLX()

source('ComparisionPReMiuM.R')
ComparisionPReMiuM()
setwd("~/Dropbox/Code/DPmixturemodel/SBC")


############################# PARAMETERS for GIBB's SAMPLING ####
iter = 100
iter.burnin = 100
iter.thin  = 5
Nps = as.integer(iter/ iter.thin)


######################### Initialize the Parameters ##############################
source('initialize.R')
initialize()

###################### Start with a good configuration ###########################
#source('startSBC.R')
#startSBC()



########### Train the Model #########################################
source('burninDPMM.R')
burninDPMM()

source('gibbsDPMM.R')
gibbsDPMM()



########## Analyze the fit ##########################################
### Good feature selection from heatmap plus cindex plus randindex
source('MCMCanalyze.R')
MCMCanalyze()

###############################
### Some plots and analysis ####
#################################
#### Generating some plots and results ON Training data ###
logrank <- survdiff(smod ~ c.final)
1 - pchisq(unlist(logrank)$chisq,df =3)
surv.fit <- survfit(smod ~ c.final)
p5 <- ggsurv(surv.fit, main = " DPMM \n Kaplan Meier Estimators \n Verhaak Cancer Data Set") + ggplot2::guides(linetype = FALSE) + ggplot2::scale_colour_discrete(name = 'Classes',breaks = c(1,2),labels = c('1', '2'))


############ Generating some Plots ##########################
pc <- prcomp(Y)
pc.pred <- predict(pc,newdata = Y)
p1 <- ggplot(as.data.frame(pc.pred), aes(x=pc.pred[,1], y= pc.pred[,2], colour= as.factor(c.final))) + ggtitle(" SBC Clustering \n VerhaakCancer Data Set") + geom_point(shape=19) + labs(y = "PC1", x = "PC2", colour = "Classes") 

